/**
 * 
 */
package de.acxiom.application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

/**
 * @author Jim Pizagno
 *
 */
public class FirmMatchkeysReducer extends MapReduceBase implements Reducer<Text, Text, Text, Text> {

	public void reduce(Text key, Iterator<Text> values, OutputCollector<Text, Text> output, Reporter reporter)
					throws IOException {
	
		ArrayList<String[]> listOfArrays = new ArrayList<String[]>();
		
		String parserField = FirmMatchkeysMapper.getParserField() ;
		
		loopManual(values, listOfArrays, parserField);

		// finished, so write any remaining array, even if they are not full.
		for (String[] myArrayString : listOfArrays) {
			emitArray(  output,key,  myArrayString);
		}
	}

	private void loopManual(Iterator<Text> values, ArrayList<String[]> listOfArrays, String parserField) {
		while (values.hasNext()) {
			String value = ((Text)values.next()).toString();
			int columnNumber = Integer.parseInt( value.split(parserField)[0] ) - 1;  // "01"->0  and "02"-1 Zero-based offsets
			String hash = value.split(parserField)[1];

			boolean placedValue = false;
			if (listOfArrays.size()>0) {  // if first entry, do not loop
				// find next empty slot
				boolean runLoop = true;
				int pos = -1;
				while(runLoop) {
					pos++;
					String[] myArrayString = listOfArrays.get(pos);
					if (myArrayString[columnNumber].length()==0) {
						myArrayString[columnNumber] = hash;
						placedValue = true;
						runLoop = false;  // optimization:  stop running loop, when value is found
					}
					if (pos+1 == listOfArrays.size()) {
						runLoop = false;
					}
				}
			}
			if(placedValue==false) {
				// need a new string
				String[] myArrayString = newString(columnNumber,hash);
				listOfArrays.add(myArrayString);
			}
		}
	}


	private void emitArray( OutputCollector<Text, Text> output, Text key, String[] myArrayString) throws IOException {
		String outline =  StringUtils.join( myArrayString, ",");
		output.collect(key, new Text(outline) );
	}

	private String[] newString(int columnNumber, String value) {
		String[] myStringArray = new String[30];
		for (int i=0 ; i<30 ; i++) {
			if(i==columnNumber) {
				myStringArray[i] = value;
			} else {
				myStringArray[i] = "";
			}
		}
		return myStringArray;
	}
	
}
