/**
 * 
 */
package de.acxiom.application;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

/**
 * @author jim pizagno
 *
 */
public class FirmMatchkeysMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {


	private static String parserField = "%%ACXIOM%%";
	
	public void map(LongWritable key, Text value, OutputCollector<Text, Text> output,
			Reporter reporter)	throws IOException {
		
		String[] fields = getFields(value);
		output.collect(new Text(fields[0]), new Text(fields[2]+parserField+fields[1]) );
	}
	
	public static String[] getFields(Text value){
		String[] fields = value.toString().split("\\t", -1);
		return fields;
	}
	
	public static String getParserField() {
		return parserField;
	}
}
